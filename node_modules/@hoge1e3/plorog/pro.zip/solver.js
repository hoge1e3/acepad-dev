function *solveExpr(predicateExpr,ctx0){
    // predicateExpr may have Variable
    ctx0=ctx0||new MatchContext();
    // ?- p(X)    ctx0 {}
    const [predicate,ctx1]=
    replace(predicateExpr,ctx0);
    //    p(^X)   ctx1 {X:^X}
    for(let outer of 
    solve(predicate,ctx1.outer)){
        let r=new MatchContext(ctx1.inner,outer);
        yield r.replacedInner();
    }
}
function *solve(predicate,outer){
    if(predicate && typeof predicate.solve==="function"){
        yield* predicate.solve(outer);
        return ;
    }
    solve.depth++;
    const ctx=new MatchContext(null,outer);
    // p(Y) :- q(X,Y),r(X).   ctx {}
    for(let p of window.db){
        const ctx2=match(predicate, p.head, ctx);
        //   ctx2  {Y:^X}
        if(!ctx2)continue;
        if(yield* solveConds(p.conds, ctx2)) break; 
    }
    solve.depth--;
}
solve.depth=0;
function* solveConds(conds,ctx){
    // return true if cut
    if(conds.length==0){
        yield ctx.outer;
        return false;
    }
    let [car, ...cdr]=conds;
    if(car===Variable.cut){
        yield* solveConds(cdr, ctx);
        return true;
    }
    // car is expr
    [car, ctx]=replace(car, ctx);
    for(let outer of solve(car, ctx.outer)){
        const ctx2=new MatchContext(ctx.inner,outer);
        if(yield* solveConds(cdr, ctx2))return true;
    }
    return false;
}
function showAns(res){
    if(res.size==0){
        dprint("yes");
    }
    for(let [k,v] of res){
        if(v===undefined)throw new Error(" null "+k);
        dprint(k,"=",v,"\n");
    }
}