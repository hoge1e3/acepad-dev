if(!Tonyu.load)Tonyu.load=(_,f)=>f();
Tonyu.load({"language":"js","compiler":{"namespace":"user","outputFile":"js/concat.js","defaultSuperClass":"jslker.Parent","dependingProjects":[{"namespace":"jslker"}]}}, ()=>{
Tonyu.klass.define({
  fullName: 'user.ace',
  shortName: 'ace',
  namespace: 'user',
  superclass: Tonyu.classes.jslker.Parent,
  includes: [],
  methods: function (__superClass) {
    return {
      main :function _trc_ace_main() {
        var _this=this;
        
      },
      fiber$main :function* _trc_ace_f_main(_thread) {
        var _this=this;
        
        
      },
      __dummy: false
    };
  },
  decls: {"methods":{"main":{"nowait":false,"isMain":true,"vtype":{"params":[],"returnValue":null}}},"fields":{}}
});

});

//# sourceMappingURL=concat.js.map