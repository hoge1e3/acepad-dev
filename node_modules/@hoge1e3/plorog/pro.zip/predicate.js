function predicate(n){
    return function (...args){
        return {
            predicateName:n,args
        }
    };
}
function *prtf(outer){
    dprint(re("-",solve.depth),this.args,"\n");
    yield outer;
}

const prt=(...args)=>({solve:prtf,args});
    