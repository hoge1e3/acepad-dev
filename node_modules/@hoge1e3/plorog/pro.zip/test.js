async function main(){
    await eval2("db.js");
    await eval2("solver.js");
    await initDB();
    let v=(n)=>{
        return new Variable(n);
    };
    let vs=(ns)=>ns.split(",").map(v);
    let o=(n)=>{
        return new OutputChannel(v(n));
    };
    let os=(ns)=>ns.split(",").map(o);
    
    //let x=o("x");
    let [x,y,z,p,n]=vs("x,y,z,p,n");
    let pred={src:p,dst:"ms5"};
    //dprint(db);
    for(let res of solveExpr(pred, new MatchContext())){
        showAns(res);
    }
    dprint("no");
}
function old(){
    let from={
        x, y:3, z
    };
    let ctx=new MatchContext();
    //let fvars=new VariableMap();
    //fvars.set("+",5)
    [from,ctx]=replace(from,ctx);
    let to={
        x:5, y, z
    };
    let r=match(from, to, ctx);
    print(r.inner.get(y));
    print("\n");
    print(r.outer.get(r.inner.get(x)));
    print("\n");
    //r=r.setOut(z,10);
    
}
main().then(e=>e, e=>{
    let s=convertStack(e);
    print(s);
    
});
/*
cnt=0;eval2("test.js");
*/