async function initDB(){
    await eval2("variable.js");
    const [x,y,z,p,n]=variables("x,y,z,p,n");
    const r=(h,...c)=>new Rule(h,c);
    function *prtf(outer){
        window.cnt=window.cnt||0;
        window.cnt++;
        if(window.cnt>1000)throw new Error("***");
        if(this.args.some(x=>x==null))throw new Error("undef");
        dprint(re("-",solve.depth),this.args,"\n");
        yield outer;
    }
    const prt=(...args)=>({solve:prtf,args});
    function re(s,i){
        let r="";
        for(;i>0;i--)r+=s;
        return r;
    }
    window.db=[
    {p:"tko",n:"snj"},
    {p:"snj",n:"tkw"},
    {p:"tkw",n:"8oj"},
    {p:"tkw",n:"hjm"},
    {p:"hjm",n:"ome"},
    {p:"hjm",n:"ms5"},
    r({src:x,dst:y},
        //prt("1",x,y),
        {p:x,n:y},
        //Variable.cut,
        //prt("4",x,y)
    ),
    r({src:x,dst:y},
        //prt("2",x,y),
        {p:x,n:z},
        {src:z,dst:y},
        //prt("3",x,z,y)
    ),
    ].map((c)=>
    c instanceof Rule?c:r(c));
/*
- 1,snj,^n 
-- 4,snj,tkw 
n = tkw 
- 2,snj,^n 
--- 1,tkw,^n 
*/
}
