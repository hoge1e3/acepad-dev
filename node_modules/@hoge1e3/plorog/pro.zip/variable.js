this.Variable=class{
    constructor(name){
        this.name=name;
    }
    toString (){
        return this.name;
    }
};
this.ImmutableMap=class{
    constructor (){
        this.map=new Map;
    }
    instantiate(){
        return new ImmutableMap();
    }
    clone(){
        const res=this.instantiate();
        for(let [k,v] of this.map){
            res.map.set(k,v);
        }
        return res;
    }
    get(k){
        if(!this.has(k)){
            throw new Error(`${k} notfound`);
        }
        return this.map.get(k);
    }
    set(k,v){
        if(this.has(k)){
            throw new Error(`${k} already`);
        }
        if(!this.validEntry(k,v)){
            throw new Error(`${k} ${v} invalid`);
        }
        const res=this.clone();
        res.map.set(k,v);
        return res;
    }
    get size(){
        return this.map.size;
    }
    has(k){
        return this.map.has(k);
    }
    [Symbol.iterator](){
        return this.map[Symbol.iterator]();
    }
};
this.OutputChannel=class{
    // {A: chn(A), B: chn(B) ....
    constructor(variable) {
        this.variable=variable;
    }  
    toString(){
        return `^${this.variable}`;
    }
};
// current implemations does not support A(X,X), 
// all channels/variables appears only once in a Predicate.
this.OutputChannelMap=class extends ImmutableMap{
    instantiate(){
        return new OutputChannelMap();
    }
    validEntry(k,v){
        return k instanceof OutputChannel;
    }
};
this.VariableMap=class extends ImmutableMap{
    instantiate(){
        return new VariableMap();
    }
    validEntry(k,v){
        return k instanceof Variable;
    }
};
this.MatchContext=class{
    constructor (inner,outer){
        this.inner=inner||new VariableMap();
        this.outer=outer||new OutputChannelMap();
        if(!(this.inner instanceof VariableMap)){
            throw new Error("invin"+this.inner);
        }
        if(!(this.outer instanceof OutputChannelMap)){
            throw new Error("invout"+this.outer);
        }
    }
    setIn(k,v){
        return new MatchContext(
            this.inner.set(k,v),
            this.outer
        );
    }
    setOut(k,v){
        return new MatchContext(
            this.inner,
            this.outer.set(k,v)
        );
    }
    replacedInner(){
        let res=new VariableMap();
        for(let [k,v] of this.inner){
            res=res.set(k,replace(v,this)[0]);
        }
        return res;
    }
} ;
function match(from, to, ctx) {
    // from,to:Predicate
    // `from` may contain OutputChannel but no Variable.
    // `to` may contain Variable 
    //returns binding {var_in_to: value}
    //  value may contain OutputChannel in from
    if(from===undefined||to===undefined)return false;
    if (isPrimitive(from) && isPrimitive(to)) {
        if (from===to) return ctx;
        return false;
    }
    if (to instanceof Variable) {
        if(ctx.inner.has(to)){
            return match(
                from,
                ctx.inner.get(to),
                ctx
            );
        }
        return ctx.setIn(to,from);
    }
    if (from instanceof OutputChannel) {
        if(ctx.outer.has(from)){
            return match(
                ctx.outer.get(from),
                to,
                ctx
            );
        }
        // `to` may contains Variable...?
        [to, ctx]=replace(to, ctx);
        return ctx.setOut(from,to);
    }
    if(isPrimitive(from) || isPrimitive(to)){
        return false;
    }
    if(isArray(from)&&isArray(to)){
        if(from.length!=to.length){
            return false;
        }
        for(let i=0;i<to.length;i++){
            ctx=match(from[i],to[i],ctx);
            if(!ctx)return false;
        }
        return ctx;
    }
    if(isArray(from) || isArray(to)){
        return false;
    }    
    for(let k in from){
        if(!(k in to))return false;
        ctx=match(from[k],to[k],ctx);
        if(!ctx)return false;
    }
    return ctx;
}
function replace(expr, ctx){
    let {inner: vars, outer}=ctx;
    if(expr instanceof Variable){
        let v=expr;
        if(vars.has(v)){
            return replace(vars.get(v), ctx);
        }
        const res=new OutputChannel(v);
        return [res, ctx.setIn(v, res)];
    }
    if(expr instanceof OutputChannel){
        if(outer.has(expr)){
            return replace(outer.get(expr),ctx);
        }
        return [expr, ctx];
    }
    if(isPrimitive(expr)){
        return [expr, ctx];
    }
    if(isArray(expr)){
        const res=[];
        for(let e of expr){
            [e,ctx]=replace(e,ctx);
            res.push(e);
        }
        return [res,ctx];
    }
    const res={};
    for(let k in expr){
        let e=expr[k];
        [e,ctx]=replace(e,ctx);
        res[k]=e;
    }
    return [res,ctx];
}
var Rule=class {
    constructor (head,conds){
        this.head=head;
        this.conds=conds;
    }
};
function isArray(v){
    return v&&
    typeof v.length=="number"&&
    typeof v.map=="function";
}
function isPrimitive(v) {
    return typeof v!=="object" || v==null;
}
function newVariable(n){
        return new Variable(n);
}
function variables(ns){
    return ns.split(",").map(newVariable);
}
Variable.cut=Symbol("cut");
//alert(VariableMap);



