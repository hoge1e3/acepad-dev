import {a} from "hoge";
export function test(){
    a();
}