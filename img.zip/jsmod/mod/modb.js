export function dob(){
    alert("mod/modb?");
}