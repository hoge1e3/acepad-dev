import {b} from './b.js';
b();