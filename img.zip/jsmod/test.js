import o from "observable";
export async function main(){
    let {locate}=this.get("acepad");
    for(let i=0;i<5;i++){
        locate(i,i);
        this.echo("hello");
        await this.sleep(0.1);
    }
}
export function test(){
    /*let f=sh.resolve("node_modules/");
    for(let e of f.listFiles()){
        if(e.ext()!==".js")continue;
        console.log(e.name());
        e.moveTo(f.rel("acepad/").rel(e.name()));
    }*/
    
    let v=o(3);    
    v((r)=>acepad.print("chg "+r));
    acepad.print("v="+v());
    v.set(57);
    //alert(3);
}
//alert(5);