// Import the functions you need from the SDKs you need
import * as firebase from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore,addDoc,collection } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";
import { getAuth, GoogleAuthProvider,signInWithPopup,signInWithRedirect,getRedirectResult  } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
async function main(){
    // Your web app's Firebase configuration
    const firebaseConfig = {
      apiKey: "AIzaSyDzw5LLCHS4AL5mP188kevh6MSo59gVAeo",
      authDomain: "acepad-d2049.firebaseapp.com",
      projectId: "acepad-d2049",
      storageBucket: "acepad-d2049.appspot.com",
      messagingSenderId: "462119605053",
      appId: "1:462119605053:web:4e7958f75006e0816eab54"
    };
    
    // Initialize Firebase
    const app = firebase.initializeApp(firebaseConfig);
    console.log(app);
    const db= getFirestore(app);
    console.log(db);
    const auth = getAuth();
    console.log(auth);
    const provider = new GoogleAuthProvider();
    //import { collection, addDoc } from "firebase/firestore"; 
    try {
        //const authres=await getRedirectResult(auth);
        const authres=await signInWithPopup(auth, provider);
        console.log(authres);
        /*if (!authres) {
            await signInWithRedirect(auth, provider);
        } else {*/
            const docRef = await addDoc(collection(db, "users"), {
                first: "Ada",
                last: "Lovelace",
                born: 1815,
                user: authres.user.uid,
            });
            console.log("Document written with ID: ", docRef.id);
        //}
    } catch (e) {
        
        console.error("Error adding document: ", e);
    }
}