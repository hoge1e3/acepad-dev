





if(FS.os){
    (async function (){
        let h=FS.get("/jsmod/");
        let b=await FS.os.loadModule(h.rel("acetest.js"));
    })();
}